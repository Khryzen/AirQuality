export default class PieController extends DoughnutController {
}
import DoughnutController from "./controller.doughnut.js";
