export function applyAnimationsDefaults(defaults: any): void;
